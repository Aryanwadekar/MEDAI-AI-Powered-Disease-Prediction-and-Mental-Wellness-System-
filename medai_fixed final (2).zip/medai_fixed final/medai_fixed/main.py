from flask import Flask, request, render_template, redirect, session, flash, jsonify
import numpy as np
import pandas as pd
import pickle, sqlite3, hashlib, os
from functools import wraps

app = Flask(__name__)
app.secret_key = "medai_super_secret_2024"

BASE    = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "instance", "users.db")
os.makedirs(os.path.join(BASE, "instance"), exist_ok=True)

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL)""")
    conn.commit(); conn.close()

def hash_pw(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

precautions = pd.read_csv(os.path.join(BASE, "Datasets/precautions_df.csv"))
workout     = pd.read_csv(os.path.join(BASE, "Datasets/workout_df.csv"))
description = pd.read_csv(os.path.join(BASE, "Datasets/description.csv"))
medications = pd.read_csv(os.path.join(BASE, "Datasets/medications.csv"))
diets       = pd.read_csv(os.path.join(BASE, "Datasets/diets.csv"))
severity_df = pd.read_csv(os.path.join(BASE, "Datasets/Symptom-severity.csv"))

MODEL_PATH = os.path.join(BASE, "models", "medai_model.pkl")
if not os.path.exists(MODEL_PATH):
    print("\n  ERROR: Run  python3 train_model.py  first!\n")
    raise SystemExit(1)

with open(MODEL_PATH, "rb") as f:
    _m = pickle.load(f)

_diseases = _m["diseases"]
_cols     = _m["cols"]
_prior    = _m["prior"]
_cpt      = _m["cpt"]
_weights  = _m["weights"]
print(f"[MedAI] Model loaded — {len(_diseases)} diseases ok")

severity_map = {}
for _, row in severity_df.iterrows():
    try:
        severity_map[str(row["Symptom"]).strip().lower().replace(" ","_")] = int(row["weight"])
    except: pass

symptoms_list = [
    "itching","skin_rash","nodal_skin_eruptions","continuous_sneezing","shivering",
    "chills","joint_pain","stomach_pain","acidity","ulcers_on_tongue","muscle_wasting",
    "vomiting","burning_micturition","spotting_ urination","fatigue","weight_gain",
    "anxiety","cold_hands_and_feets","mood_swings","weight_loss","restlessness",
    "lethargy","patches_in_throat","irregular_sugar_level","cough","high_fever",
    "sunken_eyes","breathlessness","sweating","dehydration","indigestion","headache",
    "yellowish_skin","dark_urine","nausea","loss_of_appetite","pain_behind_the_eyes",
    "back_pain","constipation","abdominal_pain","diarrhoea","mild_fever","yellow_urine",
    "yellowing_of_eyes","acute_liver_failure","fluid_overload","swelling_of_stomach",
    "swelled_lymph_nodes","malaise","blurred_and_distorted_vision","phlegm",
    "throat_irritation","redness_of_eyes","sinus_pressure","runny_nose","congestion",
    "chest_pain","weakness_in_limbs","fast_heart_rate","pain_during_bowel_movements",
    "pain_in_anal_region","bloody_stool","irritation_in_anus","neck_pain","dizziness",
    "cramps","bruising","obesity","swollen_legs","swollen_blood_vessels",
    "puffy_face_and_eyes","enlarged_thyroid","brittle_nails","swollen_extremeties",
    "excessive_hunger","extra_marital_contacts","drying_and_tingling_lips",
    "slurred_speech","knee_pain","hip_joint_pain","muscle_weakness","stiff_neck",
    "swelling_joints","movement_stiffness","spinning_movements","loss_of_balance",
    "unsteadiness","weakness_of_one_body_side","loss_of_smell","bladder_discomfort",
    "foul_smell_of urine","continuous_feel_of_urine","passage_of_gases",
    "internal_itching","toxic_look_(typhos)","depression","irritability","muscle_pain",
    "altered_sensorium","red_spots_over_body","belly_pain","abnormal_menstruation",
    "dischromic _patches","watering_from_eyes","increased_appetite","polyuria",
    "family_history","mucoid_sputum","rusty_sputum","lack_of_concentration",
    "visual_disturbances","receiving_blood_transfusion","receiving_unsterile_injections",
    "coma","stomach_bleeding","distention_of_abdomen","history_of_alcohol_consumption",
    "fluid_overload.1","blood_in_sputum","prominent_veins_on_calf","palpitations",
    "painful_walking","pus_filled_pimples","blackheads","scurring","skin_peeling",
    "silver_like_dusting","small_dents_in_nails","inflammatory_nails","blister",
    "red_sore_around_nose","yellow_crust_ooze"
]
symptoms_set = set(symptoms_list)

# Fuzzy / alias matching
ALIASES = {
    "fever": "high_fever",
    "sneezing": "continuous_sneezing",
    "diarrhea": "diarrhoea",
    "diarrhea": "diarrhoea",
    "stomach ache": "stomach_pain",
    "stomachache": "stomach_pain",
    "belly ache": "belly_pain",
    "tummy ache": "stomach_pain",
    "tired": "fatigue",
    "tiredness": "fatigue",
    "exhausted": "fatigue",
    "exhaustion": "fatigue",
    "rash": "skin_rash",
    "vomit": "vomiting",
    "throwing up": "vomiting",
    "nauseous": "nausea",
    "breathless": "breathlessness",
    "shortness of breath": "breathlessness",
    "sore throat": "throat_irritation",
    "chest tightness": "chest_pain",
    "palpitation": "palpitations",
    "heart racing": "fast_heart_rate",
    "rapid heartbeat": "fast_heart_rate",
    "yellow skin": "yellowish_skin",
    "yellow eyes": "yellowing_of_eyes",
    "dark pee": "dark_urine",
    "runny nose": "runny_nose",
    "stuffy nose": "congestion",
    "blocked nose": "congestion",
    "blurry vision": "blurred_and_distorted_vision",
    "red eyes": "redness_of_eyes",
    "watery eyes": "watering_from_eyes",
    "frequent urination": "polyuria",
    "increased urination": "polyuria",
    "painful urination": "burning_micturition",
    "burning urination": "burning_micturition",
    "stiff joints": "swelling_joints",
    "low appetite": "loss_of_appetite",
    "no appetite": "loss_of_appetite",
}

def fuzzy_match(raw):
    s = raw.strip().lower().replace(" ", "_")
    if s in symptoms_set:
        return s
    alias_key = raw.strip().lower()
    if alias_key in ALIASES:
        return ALIASES[alias_key]
    if s in ALIASES:
        return ALIASES[s]
    matches = [sym for sym in symptoms_list if s in sym]
    if len(matches) == 1:
        return matches[0]
    if matches:
        starts = [m for m in matches if m.startswith(s)]
        return starts[0] if starts else matches[0]
    def lev(a, b):
        if abs(len(a)-len(b)) > 4: return 99
        dp = list(range(len(b)+1))
        for i, ca in enumerate(a):
            ndp = [i+1]
            for j, cb in enumerate(b):
                ndp.append(min(dp[j]+(ca!=cb), dp[j+1]+1, ndp[-1]+1))
            dp = ndp
        return dp[-1]
    best, best_d = None, 3
    for sym in symptoms_list:
        d = lev(s, sym)
        if d < best_d:
            best, best_d = sym, d
    return best

def resolve_symptoms(parts):
    valid, mapped, unrecognized = [], {}, []
    for raw in parts:
        if not raw.strip():
            continue
        resolved = fuzzy_match(raw)
        if resolved and resolved in symptoms_set and resolved not in valid:
            valid.append(resolved)
            if resolved != raw.strip().lower().replace(" ","_"):
                mapped[raw] = resolved
        else:
            unrecognized.append(raw)
    return valid, mapped, unrecognized

def predict_disease(symptom_list, n=3):
    if not symptom_list:
        return "No symptoms entered", 0.0, []
    log_scores = {}
    for d in _diseases:
        ls = np.log(_prior[d])
        for s in symptom_list:
            if s in _cpt[d]:
                ls += _weights[s] * np.log(_cpt[d][s])
        log_scores[d] = ls
    mx    = max(log_scores.values())
    exps  = {d: np.exp(v - mx) for d, v in log_scores.items()}
    tot   = sum(exps.values())
    probs = {d: v / tot for d, v in exps.items()}
    ranked = sorted(probs.items(), key=lambda x: -x[1])
    top_n  = [(d, round(p * 100, 1)) for d, p in ranked[:n]]
    return ranked[0][0], round(ranked[0][1] * 100, 1), top_n

def get_disease_info(dis):
    dis  = dis.strip()
    desc = description[description["Disease"] == dis]["Description"]
    desc = " ".join(desc.tolist()) if len(desc) else "Description not available."
    pre  = precautions[precautions["Disease"] == dis][
               ["Precaution_1","Precaution_2","Precaution_3","Precaution_4"]]
    pre  = [list(r) for r in pre.values]
    med  = list(medications[medications["Disease"] == dis]["Medication"].values)
    die  = list(diets[diets["Disease"] == dis]["Diet"].values)
    wk   = list(workout[workout["disease"] == dis]["workout"].values)
    return desc, pre, med, die, wk

def calc_severity(syms):
    if not syms: return 0
    return min(100, int(sum(severity_map.get(s, 3) for s in syms) / (len(syms) * 7) * 100))

def login_required(f):
    @wraps(f)
    def dec(*a, **kw):
        if "user" not in session: return redirect("/")
        return f(*a, **kw)
    return dec

mental_qs = [
    "I feel nervous or anxious frequently.",
    "I have trouble sleeping.",
    "I feel overwhelmed by daily tasks.",
    "I have difficulty concentrating.",
    "I feel low or unmotivated.",
    "I feel irritated easily.",
    "I avoid social interactions.",
    "I feel tired even after rest.",
    "I overthink a lot.",
    "I feel hopeless sometimes."
]

@app.route("/")
def login_page():
    if "user" in session: return redirect("/home")
    return render_template("login.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        uname = request.form["username"]
        email = request.form["email"]
        pw    = hash_pw(request.form["password"])
        conn  = get_db()
        if conn.execute("SELECT id FROM users WHERE email=?",(email,)).fetchone():
            conn.close(); flash("Email already registered!"); return redirect("/register")
        conn.execute("INSERT INTO users(username,email,password) VALUES(?,?,?)",(uname,email,pw))
        conn.commit(); conn.close()
        flash("Account created! Please login.")
        return redirect("/")
    return render_template("register.html")

@app.route("/login", methods=["POST"])
def login():
    email = request.form["email"]
    pw    = hash_pw(request.form["password"])
    conn  = get_db()
    user  = conn.execute("SELECT * FROM users WHERE email=? AND password=?",(email,pw)).fetchone()
    conn.close()
    if user:
        session["user"] = user["username"]; return redirect("/home")
    flash("Invalid email or password."); return redirect("/")

@app.route("/logout")
def logout():
    session.clear(); return redirect("/")

@app.route("/home")
@login_required
def index():
    return render_template("index.html", name=session["user"], symptoms_list=symptoms_list)

@app.route("/api/symptoms")
def api_symptoms():
    return jsonify(symptoms_list)

@app.route("/predict", methods=["POST"])
@login_required
def predict():
    raw   = request.form.get("symptoms", "").strip()
    parts = [s.strip() for s in raw.split(",") if s.strip()]

    if not parts:
        flash("Please enter at least one symptom."); return redirect("/home")

    valid, mapped, unrecognized = resolve_symptoms(parts)

    if not valid:
        flash("No recognisable symptoms found. Try selecting from the autocomplete dropdown.")
        return redirect("/home")

    pred, conf, top3            = predict_disease(valid, n=3)
    sev                         = calc_severity(valid)
    desc, pres, meds, diet, wk = get_disease_info(pred)
    my_pre = pres[0] if pres else []

    return render_template("index.html",
        name=session["user"], symptoms_list=symptoms_list,
        predicted_disease=pred, confidence=conf, top_predictions=top3,
        severity_score=sev, dis_des=desc, my_precautions=my_pre,
        medications=meds, my_diet=diet, workout=wk,
        entered_symptoms=valid, invalid_symptoms=unrecognized,
        mapped_symptoms=mapped)

@app.route("/mental_health", methods=["GET","POST"])
@login_required
def mental_health():
    if request.method == "POST":
        score = sum(int(request.form.get(f"q{i}",0)) for i in range(len(mental_qs)))
        if   score <= 10: result,level,advice = "Low Stress",     "low",      "You're doing great! Keep maintaining healthy habits."
        elif score <= 20: result,level,advice = "Moderate Stress","moderate", "Try relaxation techniques, regular exercise and quality sleep."
        else:             result,level,advice = "High Stress",    "high",     "Please consider speaking with a mental health professional."
        return render_template("mental_result.html",
            score=score, result=result, level=level, advice=advice, max_score=30)
    return render_template("mental_health.html", questions=mental_qs)

@app.route("/meditation/<level>")
@login_required
def meditation(level):

    if level == "low":
        videos = [
            {"title": "5 Minute Relax Meditation",
             "url": "https://www.youtube.com/embed/inpok4MKVLM"}
        ]

    elif level == "moderate":
        videos = [
            {"title": "Stress Relief Meditation",
             "url": "https://www.youtube.com/embed/ZToicYcHIOU"},
            {"title": "Yoga for Mind Balance",
             "url": "https://www.youtube.com/embed/v7AYKMP6rOE"}
        ]

    else:  # high stress
        videos = [
            {"title": "Deep Calming Meditation",
             "url": "https://www.youtube.com/embed/MIr3RsUWrdo"},
            {"title": "Anxiety Relief Yoga",
             "url": "https://www.youtube.com/embed/ZToicYcHIOU"}
        ]

    return render_template("meditation.html", level=level, videos=videos)

@app.route("/about")
def about():   return render_template("about.html")
@app.route("/contact")
def contact(): return render_template("contact.html")
@app.route("/blog")
def blog():    return render_template("blog.html")

if __name__ == "__main__":
    init_db()
    app.run(debug=True, port=5000)

import pandas as pd
import numpy as np
import pickle
import os

print("==================================================")
print("  MedAI - Model Training (No sklearn needed)")
print("==================================================")

BASE = os.path.dirname(os.path.abspath(__file__))
os.makedirs(os.path.join(BASE, "models"), exist_ok=True)

print("\n[1/4] Loading Training.csv ...")
df       = pd.read_csv(os.path.join(BASE, "Datasets/Training.csv"))
cols     = [c for c in df.columns if c != "prognosis"]
diseases = list(df["prognosis"].unique())
print(f"      {len(df)} rows | {len(diseases)} diseases | {len(cols)} symptoms")

print("\n[2/4] Training Weighted Naive Bayes model ...")
alpha = 1.0
total = len(df)

prior = {}
cpt   = {}
for d in diseases:
    rows     = df[df["prognosis"] == d]
    n        = len(rows)
    prior[d] = n / total
    cpt[d]   = {col: float((rows[col].sum() + alpha) / (n + 2*alpha)) for col in cols}

weights = {}
for sym in cols:
    freqs          = np.array([cpt[d][sym] for d in diseases])
    var            = float(np.var(freqs))
    entropy        = float(-np.sum(freqs * np.log(freqs + 1e-10)))
    weights[sym]   = 1.0 + var * 20.0 + 5.0 / (entropy + 0.1)

def predict(symptom_list):
    log_scores = {}
    for d in diseases:
        ls = np.log(prior[d])
        for s in symptom_list:
            if s in cpt[d]:
                ls += weights[s] * np.log(cpt[d][s])
        log_scores[d] = ls
    mx    = max(log_scores.values())
    exps  = {d: np.exp(v - mx) for d, v in log_scores.items()}
    tot   = sum(exps.values())
    probs = {d: v / tot for d, v in exps.items()}
    best  = max(probs, key=probs.get)
    return best, round(probs[best] * 100, 1)

print("\n[3/4] Validating accuracy ...")
tests = [
    (["headache", "cough"],                                   "Common Cold"),
    (["headache", "cough", "runny_nose"],                     "Common Cold"),
    (["runny_nose", "sneezing", "congestion"],                "Common Cold"),
    (["itching", "skin_rash", "nodal_skin_eruptions"],        "Fungal infection"),
    (["high_fever", "headache", "nausea", "vomiting"],        "Dengue"),
    (["fatigue", "weight_loss", "high_fever", "cough"],       "Tuberculosis"),
    (["chest_pain", "breathlessness", "fast_heart_rate"],     "Pneumonia"),
    (["burning_micturition", "bladder_discomfort"],           "Urinary tract infection"),
    (["back_pain", "neck_pain"],                              "Cervical spondylosis"),
    (["pus_filled_pimples", "skin_rash", "blackheads"],       "Acne"),
    (["weight_gain", "fatigue", "cold_hands_and_feets"],      "Hypothyroidism"),
    (["fever", "chills", "headache", "sweating"],             "Malaria"),
    (["yellowish_skin", "dark_urine"],                        "Jaundice"),
    (["irregular_sugar_level", "fatigue", "weight_loss"],     "Diabetes "),
    (["joint_pain", "swelling_joints", "movement_stiffness"], "Osteoarthristis"),
]
passed = 0
for syms, expected in tests:
    pred, conf = predict(syms)
    ok   = expected.strip().lower() in pred.strip().lower()
    passed += ok
    print(f"  {'PASS' if ok else 'FAIL'}  {', '.join(syms):50s} => {pred} ({conf}%)")

print(f"\n      Score: {passed}/{len(tests)} correct")

print("\n[4/4] Saving model ...")
save_path = os.path.join(BASE, "models", "medai_model.pkl")
with open(save_path, "wb") as f:
    pickle.dump({"diseases": diseases, "cols": cols,
                 "prior": prior, "cpt": cpt, "weights": weights}, f)
print(f"      Saved -> models/medai_model.pkl")
print("\n==================================================")
print("  Training complete!  Now run:  python3 main.py")
print("==================================================")
